源自于[Pin+](http://t.cn/AiNZk0gT)源码修改而成

抽离成功能单一强大的分词功能 修改了些 bug 和 布局

用于集成于 Shortcuts 中分词模块

目前结合 Screenshot + Shortcuts + 白描 + JSBox, 屌得不行....

### 主要功能介绍

读取剪贴板 分词

#### Navigate Bar  
关闭 <-> 去标点 <-> 回初始值 <-> 取消选择 <-> 复制已选到剪贴板并退出

[Download WordStorm](https://xteko.com/redir?name=WordStorm&url=https%3a%2f%2fraw.githubusercontent.com%2fharryzjm%2fwordStorm%2fmaster%2fwordstorm.zip)